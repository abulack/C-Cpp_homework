#include <iostream>

using namespace std;
void Sort(int a[],int n)
{
    int i,j,k;
    for(i=0;i<n-1;i++)
    {
        k=i;
        for(j=i+1;j<n;j++)
        {
            if(a[j]<a[k])
                k=j;


        }
        if(k!=i)
        {

                int t=a[k];
                a[k]=a[i];
                a[i]=t;

        }
    }
}
int main()
{
    int n;
    int a[100];
    cout << "Input n:";
    cin>>n;
    cout<<"Input array of"<<" "<<n<<" "<<"integers:";
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    cout<<"After sorted the array is:";
    Sort(a,n);
    for(int j=0;j<n;j++)
        {
            if(j==n-1)
                cout<<a[j];
            else
            cout<<a[j]<<" ";

        }

    cout<<endl;
    return 0;
}


