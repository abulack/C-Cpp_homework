#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;
class Ellipse
{
private:
    int x1,y1,x2,y2;
public:
    Ellipse(int xx1,int yy1,int xx2,int yy2);
    Ellipse(const Ellipse &e);
    ~Ellipse();
    double Area();
    int GetX1(){return x1;}
    int GetY1(){return y1;}
    int GetX2(){return x2;}
    int GetY2(){return y2;}
    void Show();
    void Fun(int y);
};
Ellipse::Ellipse(int xx1,int yy1,int xx2,int yy2)
{
      x1 = xx1; y1 = yy1; x2 = xx2; y2 = yy2;
}
Ellipse::Ellipse(const Ellipse &e)
{
    x1=e.x1;y1=e.y1;x2=e.x2;y2=e.y2;
}
Ellipse::~Ellipse()
{
    cout<<"xigou "<<x1<<" "<<y1<<endl;
}
double Ellipse::Area()
{
    double area=(double)(3.1415*fabs(x2-x1)*fabs(y2-y1)/4);
    return area;
}
void Ellipse::Show()
{
    cout<<x1<<" "<<y1<<" "<<x2<<" "<<y2<<endl;
}
void Ellipse::Fun(int y)
{
    y1+=y;y2-=y;
}
int main()
{
    int x1,y1,x2,y2,y;
    cin>>x1>>y1>>x2>>y2>>y;
    Ellipse e1(x1,y1,x2,y2);
    Ellipse e2(e1);
    e1.Show();
    e2.Show();
    cout<<fixed<<setprecision(4)<<e1.Area()<<endl;
    cout<<fixed<<setprecision(4)<<e2.Area()<<endl;
    e2.Fun(y);
    cout<<fixed<<setprecision(3)<<e2.Area()<<endl;
    return 0;
}

