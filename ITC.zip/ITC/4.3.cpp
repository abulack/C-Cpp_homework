#include <iostream>

using namespace std;
int read(int a[])
{
    int i=-1;
    do{i++;
        cin>>a[i];

    }while(a[i]!=-1);
    return i;
}
void Sort(int *a,int n)
{
    int i,j;
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
            if(*(a+j)>*(a+j+1))
                {
                    int t=*(a+j);
                    *(a+j)=*(a+j+1);
                    *(a+j+1)=t;

                }
             else
                    continue;
        }
    }
}
int main()
{
    int a[100],b[100];
    int n,len=0;
    n=read(a);
    Sort(a,n);
    for(int i=0;i<n;i++)
    {
        b[len]=a[i];
        len++;
        for(int j=i+1;;j++)
        {
            if(a[j]!=a[i])
            break;
            else
            {
                i++;
            };
        }
    }
    for(int m=0;m<len;m++)
        cout<<b[m]<<" ";
        cout<<endl;
    return 0;
}

