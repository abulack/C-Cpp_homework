#include <iostream>

using namespace std;
int Merge(int a[], int an, int b[], int bn, int c[]);
int Inter(int a[], int an, int b[], int bn, int d[]);
void Sort(int a[], int n);
void Print(int a[], int n);
int input(int a[])
{
    int i=-1;
    do{
        i++;
        cin>>a[i];
    }while(a[i]!=0);
    return i;
}
void Sort(int a[],int n)
{
    int i,j,k;
    for(i=0;i<n-1;i++)
    {
        k=i;
        for(j=i+1;j<n;j++)
        {
            if(a[k]>a[j])
            {
                k=j;
            }
        }
        if(k!=i)
        {
            int temp;
            temp=a[k];
            a[k]=a[i];
            a[i]=temp;
        }
    }
}
void Print(int a[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
int Merge(int a[], int an, int b[], int bn, int c[])
{
    int i,j,k;

    for(i=0,j=0,k=0;i<an&&i<bn;)
    {
        if(a[i]<b[j])
        {
            c[k]=a[i];
            i++;
            k++;
        }
        else if(a[i]>b[j])
        {
            c[k]=b[j];
            j++;
            k++;

        }
        else
        {
            c[k]=a[i];
            i++;
            j++;
            k++;
        }
    }
        if(i<an)
        {
            for(;i<an;++i)
            {
                c[k]=a[i];
                k++;
            }
        }
        else if(j<bn)
        {
           for(;j<bn;++j)
           {
               c[k]=b[j];
               k++;
           }
        }
        return k;

}
int Inter(int a[], int an, int b[], int bn, int d[])
{
    int i,j,k;
    for(i=0,j=0,k=0;i<an&&j<bn;)
    {
        if(a[i]==b[j])
        {
            d[k++]=a[i];
            i++;
            j++;

        }
        else if(a[i]>b[j])
            j++;
        else if(a[i]<b[j])
            i++;
    }
    return k;
}
int main()
{
    int a[20],b[20],c[20],d[20];
    int an,bn,k1,k2;
    an=input(a);
    bn=input(b);
    Sort(a,an);
    Sort(b,bn);
    k1=Merge(a,an,b,bn,c);
    k2=Inter(a,an,b,bn,d);
    Print(a,k1);
    Print(b,k2);
    return 0;
}



