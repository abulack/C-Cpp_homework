#include <stdio.h>
#include <stdlib.h>
double fact(int n)
{
    int i,m=1;
    for(i=1;i<=n;i++)
    {
        m*=i;
    }
    return m;
}
int main()
{
    int n,j,k;
    scanf("Enter n: ");
    scanf("%d",&n);
    for(j=1;j<=n;j++)
    {
        k=(int)fact(j);
        if(j==1)
        printf("Enter n: %d!=%d\n",j,k);
        if(j>1)
            printf("%d!=%d\n",j,k);
    }

    return 0;
}

