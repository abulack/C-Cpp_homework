#include <iostream>

using namespace std;

int main()
{
    int x,a,b,c,d,e,s=0;
    cin>>x;
    a=x/10000;
    b=x/1000%10;
    c=x/100%10;
    d=x/10%10;
    e=x%10;
    if(a>0)cout<<a<<" ",s++;
    if(b>0||a>0)cout<<b<<" ",s++;
    if(c>0||b>0||a>0)cout<<c<<" ",s++;
    if(d>0||c>0||b>0||a>0)cout<<d<<" ",s++;
    if(e>=0)cout<<e<<endl,s++;
    cout<<s<<endl;
    return 0;
}

