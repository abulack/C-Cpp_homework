#include <iostream>
#include<iomanip>
using namespace std;
#define PI 3.1415926
class Shape
{
public:
    Shape(){}
    ~Shape(){}
    virtual void ShowData()=0;
    virtual void GoArea()=0;
    virtual void GoVolume()=0;
};
class pingmian:virtual public Shape
{
public:
    void ShowData()
    {
        cout<<fixed<<setprecision(2)<<area<<endl;
    }
    void GoArea(){area=0; }
    void GoVolume(){volume=0;}

    float area,volume;
};
class liti:virtual public Shape
{
public:
    void ShowData(){cout<<fixed<<setprecision(2)<<volume<<endl;}
    void GoArea(){area=0;}
    void GoVolume(){volume=0;}

    float area,volume;
};
class Circle:public pingmian
{
private:
    float r;
public:
    void GoArea()
    {
        cin>>r;
        area=PI*r*r;
    }

};
class Ellipse:public pingmian
{
private:
    float a,b;
public:
    void GoArea()
    {
       cin>>a>>b;
       area=PI*a*b;
    }
};
class Rectangle:public pingmian
{
private:
    float a,b;
public:
    void GoArea()
    {
        cin>>a>>b;
        area=a*b;
    }
};
class Tag :public pingmian
{
private:
    float d,h;
public:
    void GoArea()
    {
        cin>>d>>h;
        area=1.0/2*d*h;
    }
};
class Ball:public liti
{
private:
    float R;
public:
    void GoVolume()
    {
        cin>>R;
        volume=4.0/3*PI*R*R*R;
    }
};
class Column:public liti
{
private:
    float R,H;
public:
    void GoVolume()
    {
        cin>>R>>H;
        volume=PI*R*R*H;
    }
};
class Cuboid:public liti
{
private:
    float A,B,H;
public:
    void GoVolume()
    {
        cin>>A>>B>>H;
        volume=A*B*H;
    }
};
int main()
{
    Shape *p;
    Circle c;
	Ellipse e;
	Rectangle r;
	Tag t;
	Ball b;
	Column co;
	Cuboid cb;
	int n;
	cin>>n;
	switch (n)
	{
    case 1:
        p=&c;
        p->GoArea();
        p->ShowData();
        break;
    case 2:
        p=&e;
        p->GoArea();
        p->ShowData();break;
    case 3:
        p=&r;
        p->GoArea();
        p->ShowData();break;
    case 4:
        p=&t;
        p->GoArea();
        p->ShowData();
    case 5:
        p=&b;
        p->GoVolume();
        p->ShowData();break;
    case 6:
        p=&co;
        p->GoVolume();
        p->ShowData();break;
    case 7:
        p=&cb;
         p->GoVolume();
        p->ShowData();break;
    default:
        break;
	}
    return 0;
}
