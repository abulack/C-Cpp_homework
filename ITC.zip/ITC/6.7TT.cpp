#include<iostream>
#include<iomanip>
using namespace std;
#define PI 3.14159265
class Shape
{
public:
	virtual void ShowData() = 0;//���麯����ֻҪ����Ϊ���麯��������������඼�����󶨡�
	virtual void GoArea() = 0;
	virtual void GoVolume() = 0;
private:
};
class Plane_Figure:virtual public Shape
{
public:
	void ShowData() { cout << fixed << setprecision(2) << area << endl; }
	void GoArea() { area = 0; }
	void GoVolume() { volume = 0; }

	double area;
	double volume;
};
class Solid_Figure:virtual public Shape
{
public:
	void ShowData() { cout << fixed << setprecision(2) << volume << endl; }
	void GoArea() { area = 0; }
	void GoVolume() { volume = 0; }

	double area;
	double volume;
};
class Circle :public Plane_Figure
{
public:
	void ShowData() { cout << fixed << setprecision(2) << area << endl; }
	void GoArea()
	{
		cin >> r;
		area = PI*r*r;
	}
private:
	int r;
};
class Ellipse :public Plane_Figure
{
public:
	void ShowData() { cout << fixed << setprecision(2) << area << endl; }
	void GoArea()
	{
		cin >> a >> b;
		area = PI*a*b;
	}
private:
	int a;
	int b;
};
class Rectangle :public Plane_Figure
{
public:
	void ShowData() { cout << fixed << setprecision(2) << area << endl; }
	void GoArea()
	{
		cin >> l >> w;
		area = l*w;
	}
private:
	int l;
	int w;
};
class Tag :public Plane_Figure
{
public:
	void ShowData() { cout << fixed << setprecision(2) << area << endl; }
	void GoArea()
	{
		cin >> b >> h;
		area = (b*h) / 2;
	}
private:
	int b;
	int h;
};
///
class Ball :public Solid_Figure
{
public:
	void ShowData() { cout << fixed << setprecision(2) << volume << endl; }
	void GoVolume()
	{
		cin >> R;
		volume = (4 * PI*R*R*R) / 3;
	}
private:
	int R;
};
class Column :public Solid_Figure
{
public:
	void ShowData() { cout << fixed << setprecision(2) << volume << endl; }
	void GoVolume()
	{
		cin >> R >> H;
		volume = PI*R*R*H;
	}
private:
	int R;
	int H;
};
class Cuboid :public Solid_Figure
{
public:
	void ShowData() { cout << fixed << setprecision(2) << volume << endl; }
	void GoVolume()
	{
		cin >> L >> W >> H;
		volume = L*W*H;
	}
private:
	int L;
	int W;
	int H;
};

int main()
{
	Shape *p;
	Circle cc;
	Ellipse e;
	Rectangle r;
	Tag t;
	Ball b;
	Column cl;
	Cuboid cb;
	int n;
	cin >> n;
	switch (n)
	{
	case 1://Բ��
		p = &cc;
		p->GoArea();
		p->ShowData(); break;
	case 2://��Բ
		p = &e;
		p->GoArea();
		p->ShowData(); break;
	case 3://����
		p = &r;
		p->GoArea();
		p->ShowData(); break;
	case 4://������
		p = &t;
		p->GoArea();
		p->ShowData(); break;
	case 5://��
		p = &b;
		p->GoVolume();
		p->ShowData(); break;
	case 6://Բ����
		p = &cl;
		p->GoVolume();
		p->ShowData(); break;
	case 7://������
		p = &cb;
		p->GoVolume();
		p->ShowData(); break;
	default:
		break;
	}
    return 0;
}

