#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    int n,i;
    double sum;
    cout<<"Enter n:";
    cin>>n;
    for(i=1;i<=2*n-1;i=i+2)
    {
        sum+=1.0/i;
    }
    printf(" sum=%0.6f",sum);

    return 0;
}



