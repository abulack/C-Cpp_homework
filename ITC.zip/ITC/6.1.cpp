#include <iostream>

using namespace std;
class BaseClass
{
public:
    void fn1()
    {
        cout<<"Call Base fn1()"<<endl;
    }
    void fn2()
    {
        cout<<"Call Base fn2()"<<endl;
    }
};
class DerivedClass :public BaseClass
{
public:
    void fn1()
    {
        cout<<"Call Derive fn1()"<<endl;
    }
    void fn2()
    {
        cout<<"Call Derive fn2()"<<endl;
    }

};
int main()
{

        DerivedClass D;

        DerivedClass *pD=&D;

        BaseClass *pB=&D;

        D.fn1();

        D.fn2();

        pD->fn1();

        pD->fn2();

        pB->fn1();

        pB->fn2();

        return 0;

}

