#include <iostream>
#include<cstring>
using namespace std;
class Student
{
private:

    string name;
    int grade;
public:
    static int total;
    static void Average(int sum);
    Student()
    {
        cin>>name>>grade;
        total+=grade;
    }
};
void Student::Average(int sum)
{
    cout<<total/sum;

}
int Student::total=0;
int main()
{
    Student stu[5];
    cout<<Student::total<<endl;
    Student::Average(5);
    return 0;
}

