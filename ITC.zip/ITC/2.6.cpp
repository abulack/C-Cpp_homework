#include <iostream>

using namespace std;

int main()
{
    int m,n,i,g,s,b;
    cout<<"Input m: "<<"Input n: ";
    cin>>m;
    cin>>n;
    for(i=m;i<=n;i++)
    {

        if(i<10)
        {
            g=i%10;
            if(g*g*g==i)
        {
            cout<<i<<endl;
        }
        }
        if(i<100&&i>=10)
    {
        s=i/10;
        b=i%10;
        if(g*g*g+s*s*s==i)
        {
            cout<<i<<endl;
        }
    }
        else if(i>=100)
    {
        g=i%10;
        s=i/10%10;
        b=i/100;
        if(g*g*g+b*b*b+s*s*s==i)
            cout<<i<<endl;
    }
    }

    return 0;
}







