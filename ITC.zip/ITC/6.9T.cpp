#include <iostream>

using namespace std;
class BaseClass
{
public:
    void fn1();
    void fn2();
};
void BaseClass::fn1()
{
    cout<<"calling fn1() of the base class"<<endl;
}
void BaseClass::fn2()
{
    cout<<"calling fn2() of the base class"<<endl;
}
class DerivedClass :public BaseClass
{
  public:
    void fn1();
    void fn2();
};
void DerivedClass::fn1()
{
    cout<<"calling fn1() of the derived class"<<endl;
}
void DerivedClass::fn2()
{
    cout<<"calling fn2() of the derived class"<<endl;
}
int main(){

DerivedClass D;

DerivedClass *pD=&D;

BaseClass *pB=&D;

D.fn1();D.fn2();

pD->fn1();pD->fn2();

pB->fn1();pB->fn2();

return 0;

}

