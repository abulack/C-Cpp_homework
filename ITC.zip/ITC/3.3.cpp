#include <iostream>

using namespace std;
#define x 10
void input(int a[]);
void exchange(int *a,int *b);
void sort(int a[]);
int search(int a[],int m);
void exchange(int *a,int *b)
{
    int term;
    term=*a;
    *a=*b;
    *b=term;
}
void sort(int a[])
{
    int i,j;
    for(i=0;i<x-1;i++)
    {
        for(j=0;j<x-1-i;j++)
        {
            if(a[j]>a[j+1])
                exchange(&a[j],&a[j+1]);
            else
                continue;
        }
    }
}
int search(int a[],int m)
{
    int low,high,mid;
    low=0,high=x-1,mid=(low+high)/2;
    while(a[mid]!=m&&low<high)
    {
        if(m>a[mid])
        {
            low=mid+1;
        }
        else
        {
            high=mid-1;
        }
        mid=(low+high)/2;
    }
    if(a[mid]==m)
    {
        return 1;
    }
    else
        return 0;

}
void input(int a[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        cin>>a[i];
    }
}
int main()
{
    int a[x];
    int result;
    int m;
    input(a,x);
    sort(a);
    for(int i=0;i<x;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    cin>>m;
    result = search(a,m);
    if(result==1)cout<<"yes"<<endl;
    else
        cout<<"no"<<endl;




    return 0;
}


