#include <iostream>
#include <cmath>
#include <iomanip>
#include <cstdio>
using namespace std;

int main()
{
   float x,y,z,s,area;
   scanf("%f%f%f",&x,&y,&z);
   if(x+y>z&&x+z>y&&y+z>x)
 {   s=(float)1/2*(x+y+z);
   area=sqrt(s*(s-x)*(s-y)*(s-z));
   printf("%.3f",area);

 }
   else
    cout<<"ERROR"<<endl;

}



