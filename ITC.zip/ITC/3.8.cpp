#include <iostream>
#include <cstdio>

using namespace std;
float aver(int a[][4],int n)
{
    float sum=0,aver;


    for(int j=0;j<4;j++)
    sum+=a[n][j];
    aver=sum/4;
    return aver;


}
void input(int a[][4] ,int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<4;j++)
        {
            cin>>a[i][j];
        }
    }
}
int main()
{
    int a[100][4];
    int n;
    cin>>n;
    input(a,n);
    for(int i=0;i<n;i++)
    {
        printf("%.2f\n",aver(a,i));
    }
    return 0;
}

