#include <iostream>

using namespace std;
#define x 10
void input(int a[],int n)
{
    for(int i=0;i<n;i++)
        cin>>a[i];
}
void output(int a[],int n)
{
    for(int i=0;i<n;i++)
        cout<<a[i]<<" ";
    cout<<endl;
}
int main()
{
    int a[x];
    int b[x-1];
    int m=0;
    int n;
    input(a,x);
    cin>>n;
    for(int i=0;i<x;i++)
    {

        if(a[i]!=n)
        {
            b[m]=a[i];
        }

        else continue;
        m++;
    }
    if(m==x)
        cout<<"输入数据不存在"<<endl;
    else
        output(b,m);
    return 0;
}

