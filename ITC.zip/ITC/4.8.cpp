#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
char *Mystrcat(char *s1,char *s2)
{
    char *ps1=s1;
    while(*s1!='\0')s1++;
    for(;*s2!='\0';s1++,s2++)
    {
        *s1=*s2;
    }
    *s1='\0';
    return ps1;
}
int main()
{
    char s1[100],s2[100];
    gets(s1);
    gets(s2);
    cout<<Mystrcat(s1,s2)<<endl;
    return 0;
}

