#include <iostream>
#include<cstring>
using namespace std;
class String
{
private:
    unsigned int len;
    char* str;
public:
    String(){str=NULL;len=0;}
    String(const char* mstr)
    {
        len=strlen(mstr);
        str=new char[len+1];
        strcpy(str,mstr);

    }
    String(const String& s);
    friend bool operator<(const String &s1,const String &s2);
    friend ostream& operator<<(ostream &out,const String &s);
    ~String();

};
String:: String(const String& s)
{
    len=s.len;
    str=new char[len+1];
    strcpy(str,s.str);
}
String::~String(){if(str)delete[]str;}
bool operator<(const String &s1,const String &s2)
{
    return strcmp(s1.str,s2.str)<0?true:false;
}
ostream& operator<<(ostream &out,const String &s)
{
    out<<s.str<<endl;//out=s.str;��������Ǹ�ֵ�Ļ�����û�б�Ҫ����ostream�ࣻ
    return out;
}
template<class T>//�ǵ�д����������������+������+�����б�
T Min(T a,T b)
{
    return a<b?a:b;
}
char* Min(char* a,char* b)
{
    return strcmp(a,b)<0?a:b;
}
int main()

{

  int x,y;

  double a,b;

  char c1[20],c2[20],c3[20],c4[20];

  cin>>x>>y;

  cout<<Min(x,y)<<endl;

  cin>>a>>b;

  cout<<Min(a,b)<<endl;

  cin>>c1>>c2;

  cout<<Min(c1,c2)<<endl;

  cin>>c3>>c4;

  String s1(c3),s2(c4);

  cout<<Min(s1,s2)<<endl;

  return 0;

}
