#include <iostream>

using namespace std;
class Point3D
{
private:
    int my_x,my_y,my_z;
public:
    Point3D(int x=0,int y=0,int z=0){my_x=x;my_y=y;my_z=z;}
    void SetPoint(int x1,int y1,int z1)
    {
        my_x=x1;my_y=y1;my_z=z1;
    }
    Point3D operator+(Point3D &p);
    friend Point3D& operator+(int n,Point3D& p);
    friend ostream & operator<<(ostream &out, const Point3D &pt);
};
Point3D Point3D::operator+(Point3D &p)//���м������󣬼ǵ÷������Ͳ������ã�ע�⹹�캯��
{

    Point3D temp(my_x+p.my_x,my_y+p.my_y,my_z+p.my_z);
    return temp;

    //my_x+=p.my_x;my_y+=p.my_y;my_z+=p.my_z;
    //return *this;
    //this->my_x+=p.my_x; this->my_y+=p.my_y; this->my_z+=p.my_z;
    //return *this;
    /*Point3D temp;
    temp.my_x+=p.my_x;
    temp.my_y+=p.my_y;
    temp.my_z+=p.my_z;
    return temp;*/
}
Point3D& operator+(int n,Point3D& p)
{
   p.my_x+=n;
   return p;
}
ostream & operator<<(ostream &out, const Point3D &pt)
{
    out<<pt.my_x<<","<<pt.my_y<<","<<pt.my_z<<endl;
    return out;
}
int main()

{

    Point3D pt1, pt2, pt3, pt4;

    pt1.SetPoint(10, 20, 3);

    pt2.SetPoint(40, 50, 60);

    pt3 = pt1+pt2;

    cout<<"pt1:"<<pt1;

    cout<<"pt2:"<<pt2;

    cout<<"pt1+pt2:"<<pt3;

    pt4 = 3+pt1;

    cout<<"3+pt1:"<<pt4;

    return 0;

}
