#include <iostream>

using namespace std;

int main()
{
    int i,j,n;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=2*n-2*i;j++)
        cout<<" ";
        cout<<1;
        for(j=2;j<=i;j++)
        cout<<" "<<j;
        for(j=i-1;j!=0;j--)
        cout<<" "<<j;
        cout<<endl;
    }
    for(i=n-1;i!=0;i--)
    {
        for(j=1;j<=2*n-2*i;j++)cout<<" ";

        cout<<1;
        for(j=2;j<=i;j++)cout<<" "<<j;

        for(j=i-1;j!=0;j--)cout<<" "<<j;

        cout<<endl;
    }
    return 0;
}

