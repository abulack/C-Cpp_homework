#include <iostream>
#include <cstring>

using namespace std;
class String
{
private:
    char *mydata;
public:
    String(const char *str=NULL);
    String(const String &r);
    ~String();
};
String::String(const char *str)
{
    if(str==NULL)
    {
        cout<<"gouzao"<<endl;
        mydata=NULL;
    }
    else
    {
        cout<<"gouzao"<<" "<<str<<endl;
        int len = strlen(str);
        mydata=new char[len+1];
        strcpy(mydata,str);
    }
}
String::String(const String &r)
{
    cout<<"kaobei gouzao"<<" "<<r.mydata<<endl;
    int len=strlen(r.mydata);
    mydata=new char[len+1];
    strcpy(mydata,r.mydata);
}
String::~String()
{
    if(mydata==NULL)
    {
        cout<<"xigou"<<endl;
    }
    else
    {
        cout<<"xigou"<<" "<<mydata<<endl;
    }
    delete []mydata;
}
int main() //�����޸�������

{

  String s1,s2("hello");

  String s3(s2);

  return 0;

}

