#include <iostream>
#include<cstring>
using namespace std;

class  String {
 char  *ptr;
public:
 String(const char  *s)
 {
  ptr=new  char[strlen(s)+1];
  strcpy(ptr, s);
 }
 ~String() {  delete  []ptr; }
 void print() { cout<<ptr<<endl; }
 String()
 {
     ptr=NULL;
 }
 String &operator=(const String& s2)
 {
     if(this==&s2)
     {
         return *this;
     }
     else
     {
         this->ptr=new char[strlen(s2.ptr)];
         strcpy(this->ptr,s2.ptr);
         return *this;
     }
 }
 String& operator+=(const String &s)
 {
     char* pnew=ptr;
     ptr=new char[strlen(ptr)+strlen(s.ptr)];
     strcpy(ptr,pnew);
     strcat(ptr,s.ptr);
     delete[]pnew;
     return *this;
 }
 friend ostream& operator<<(ostream& out,const String& s);

};
ostream& operator<<(ostream& out,const String& s)
{
     out<<s.ptr<<endl;
     return out;
 }
int  main( )
{ String  p1("book"), p2("pen"),p3("good"),p4;
 p4 = p4 = p1 ;
 p3 = p1 = p2;
 cout<<"p2:";
 p2.print();
 cout<<"p1:"<<p1;
 cout<<"p3:"<<p3;
 p4+=p3;
 cout<<"p4:"<<p4;
 return 0;
}
