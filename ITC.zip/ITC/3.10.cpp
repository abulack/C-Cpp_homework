#include <iostream>
#include <cstdio>


using namespace std;

int main()
{
    char a[100];
    int i,m=0,n=0,len=0,count=0;
    char ch,c;
    cin>>c;
    cin>>ch;
    for(i=0;ch!='\n';i++)
    {
        a[i]=ch;
        len++;
        ch=getchar();
    }
    for(i=0;i<len;i++)
    {
        if(c==a[i])
        {
            count++;
            m++;
        }
         while(a[i]==32||a[i]==44||a[i]==46)
        {
        if(m!=0)
        {
            n++;
            m=0;
        }
        break;
        }
    }
   cout<<count<<" "<<n<<endl;
    return 0;
}

