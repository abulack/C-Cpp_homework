#include <iostream>

using namespace std;

int main()
{
    int a,b;
    char ch;
    while(cin>>a>>b>>ch)
    {
    if(a==0&&b==0)return 0;
    switch (ch)
            {
                case '+':cout<<a+b<<endl;

                    break;
                case '-':cout<<a-b<<endl;

                    break;
                case '*': cout<<a*b<<endl;

                    break;
                case '/':
                    if(b==0)cout<<"Error"<<endl;
                    else   cout<<a/b<<endl;

                    break;
                case '%':
                     cout<<a%b<<endl;
                     break;

                default:cout<<"Error"<<endl;

                    break;
            }

        }



   return 0;
}


