#include <iostream>

using namespace std;
void Swap(int *x, int *y)
{
    int temp=*x;
    *x=*y;
    *y=temp;
}
void FindMaxMinid(int arr[], int nCount, int *max_id, int *min_id)
{
    for(int i=0;i<nCount;i++)
    {
        if(arr[i]>max_id[0])
        {
            max_id=&arr[i];
        }
        if(arr[i]<min_id[0])
        {
            min_id=&arr[i];
        }

    }
    Swap(max_id,min_id);
}
int main()
{
    int a[10];
    for(int i=0;i<10;i++)
    {
        cin>>a[i];
    }
    FindMaxMinid(a,10,a,a);
    for(int i=0;i<10;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    return 0;
}

