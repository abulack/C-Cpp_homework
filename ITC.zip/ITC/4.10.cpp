#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
void interdelet(char a[],char b[])
{
    int i,j;
    for(j=0;j<(int)strlen(b);j++)
    {
        for(i=0;i<(int)strlen(a);i++)
        {
            if(b[j]==a[i])
            {
                int k;
                for(k=i;k<(int)strlen(a)-1;k++)
                {
                    a[k]=a[k+1];
                }
                a[k]='\0';
                i--;
            }
        }
    }
}
void Sort(char a[])
{
    for(int i=0;i<(int)strlen(a)-1;i++)
    {
        int index=i;
        for(int j=i+1;j<(int)strlen(a);j++)
        {
            if(a[index]>a[j])
                index=j;

        }
        if(index!=i)
        {
            int temp=a[index];
            a[index]=a[i];
            a[i]=temp;
        }
    }
}
void Delet(char a[])
{
    for(int i=0;i<(int)strlen(a);i++)
    {
        if(a[i]==a[i+1])
        {
            int k;
            for(k=i;k<(int)strlen(a)-1;k++)
                a[k]=a[k+1];
            a[k]='\0';
            i--;

        }
    }
}
int main()
{
    char a[50],b[50];
    gets(a);
    gets(b);
    interdelet(a,b);
    Sort(a);
    Delet(a);
     if( a[0] != 0 )
        cout << a << endl;
    else
        cout << "NULL" << endl;
    return 0;
}

