#include <stdio.h>
#include <stdlib.h>

int main()
{   char x[100],y[100],z[100];
    scanf("%s",x);

    scanf("%s",y);
    scanf("%s",z);

    printf("%s\n",x);
    printf("%s\n",y);








    printf("%s\n",z);
    return 0;
}


