#include <iostream>

using namespace std;
void Insert(int a[],int pos,int num)
{
    if(pos>10)
        cout<<"输入位置不正确";
    else if(pos>=0)
    {
        int temp=a[pos];
        a[pos]=num;

        for(int j=10;j>pos+1;j--)
            a[j]=a[j-1];
        a[pos+1]=temp;
        for(int i=0;i<11;i++)
        {
            cout<<a[i]<<" ";
        }
    }
}
int main()
{
    int pos,num;
    int a[100];
    for(int i=0;i<10;i++)
    {
        cin>>a[i];
    }
    cin>>pos>>num;
    Insert(a,pos,num);

    return 0;
}

