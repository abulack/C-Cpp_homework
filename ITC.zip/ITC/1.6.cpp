#include <iostream>

using namespace std;

int main()
{
    float x;
    int y;
    cin>>x;
    if(x==0)cout<<"�ȼ�"<<endl;
    else
     {

        y=x/10;
        switch (y)
        {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                cout<<"E"<<endl;
                break ;
            case 6:
                cout<<"D"<<endl;
                break ;
            case 7:
                cout<<"C"<<endl;
                break ;
            case 8:
                cout<<"B"<<endl;
                break ;
            case 9:
            case 10:
                cout<<"A"<<endl;
                break;
            default:
                cout<<"wrong"<<endl;

        }
     }
    return 0;
}

