#include <iostream>

using namespace std;
class CBase1{

    int x ;

public:

    CBase1( ) { x=0 ; cout<<"GZ CBase1()!"<<endl;}

    CBase1(int a) { x=1;cout<<"GZ CBase1(int)!"<<endl;}

    ~CBase1( ) { cout<<"XG ~CBase1()!"<<endl;}

};

class CBase2{

    int y;

public:

    CBase2( ) { y=0 ;cout<<"GZ CBase2()!"<<endl;}

    CBase2(int a) { y=a ;cout<<"GZ CBase2(int)!"<<endl;}

    ~CBase2() { cout<<"XG ~CBase2()!"<<endl;}

};

class A{

    int x;

public:

    A () {x=0; cout<<"GZ A()!"<<endl;}

    A(int a) { x=a; cout<<"GZ A(int)!"<<endl;}

    ~A() { cout<<"XG ~A()!"<<endl;}

};

class CDerived:public CBase1, virtual public CBase2{

    A a;

public:

    CDerived() { cout<<"GZ CDerived()!"<<endl;}

    CDerived(int x,int y ,int z):a(x),CBase1(y),CBase2(z)

    { cout<<"GZ CDerived(int,int)!"<<endl;}

    ~CDerived() { cout<<"XG ~CDerived()!"<<endl;}

};
int main()
{
   CDerived* p=new CDerived;
	CDerived B(1,2,3);
	delete p;
	cout<<"main() OVER!"<<endl;

   return 0;
}

