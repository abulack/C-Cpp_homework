#include <iostream>

using namespace std;

int main()
{

  int x,gw,sw,bw;

  cin>>x;

  gw=x%10;

  bw=x/100;

  sw=(x-gw)%100/10;

  cout<<gw+bw+sw;

  return 0;

}

