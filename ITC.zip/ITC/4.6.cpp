#include <iostream>
#include <cstring>
using namespace std;
void Delete1(char s[ ], char ch)
{
    int j=0;
    while(j<strlen(s))
    {
        if(s[j]==ch)
        {
            for(int i=j;i<strlen(s);i++)
                s[i]=s[i+1];
        }

        if(s[j]==ch)
            continue;
        j++;

    }
}
int main()
{
    char s[100];
    char ch;
    cin>>s;
    cin>>ch;
    Delete1(s,ch);
    cout<<s<<endl;
    return 0;
}

