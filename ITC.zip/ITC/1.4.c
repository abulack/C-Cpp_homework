#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
  float x,y,z;
  float s,area;

  scanf("%f%f%f",&x,&y,&z);
  if(x+y>z&&x+z>y&&y+z>x)
    {
        s=(float)1/2*(x+y+z);
  area=sqrt(s*(s-x)*(s-y)*(s-z));

  printf("%.0f",area);

    }
  else
    printf(" ");

  return 0;
}



