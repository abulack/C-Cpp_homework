#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;
class Time

{

  int hour,minute,second;

public:

  Time(int h,int m, int s=0);

  Time(int s=0);

  int SecCalc(){return(hour*60+minute)*60+second;  }

  void SetTime(int h=0,int m=0, int s=0);

  void print_12();

  void print_24();

  friend Time operator+(Time& a,Time& b);
  friend Time operator+(Time& a,int t);
  friend Time operator+(int t,Time& a);

  friend Time operator-(Time& a,Time& b);
  friend Time operator-(Time& a,int t);
};
Time::Time(int h,int m, int s)
{
    hour=h;
    minute=m;
    second=s;
}
Time::Time(int s)
{
    hour=s/3600;
    minute=(s-hour*3600)/60;
    second=s-hour*3600-minute*60;
}
void Time::SetTime(int h,int m,int s)
{
    hour=h;
    minute=m;
    second=s;
}
void Time::print_12()
{
    if(hour>12)
    {
        cout<<setw(2) << setfill('0') << hour-12 << ":" << setw(2) << setfill('0') << minute << ":" << setw(2) << setfill('0') << second << " PM";
    }
    else
    {
         cout << setw(2) << setfill('0') << hour << ":" << setw(2) << setfill('0') << minute << ":" << setw(2) << setfill('0') << second << " AM";
    }
}
void Time::print_24()
{
      cout << setw(2) << setfill('0') << hour << ":" << setw(2) << setfill('0') << minute << ":" << setw(2) << setfill('0') << second;
}
Time operator+(Time& a,Time& b)
{
    int s=a.SecCalc()+b.SecCalc();
    Time tt(s);

    /*Time tt;
    tt.second=a.second+b.second;
    tt.minute=tt.second/60+a.minute+b.minute;
    tt.second%=60;*//*xiangjiazouqi,quyu*/
    //tt.hour=tt.minute/60+a.hour+b.hour;
    //tt.minute%=60;
    //tt.hour%=24;��Щ����
    return tt;
}
Time operator+(Time& a,int t)
{
    int s=a.SecCalc()+t;
    Time tt(s);
    return tt;

}
Time operator+(int t,Time& a)
{
    int s=a.SecCalc()+t;
    Time tt(s);
    return tt;
}
Time operator-(Time& a,Time& b)
{
    int s=fabs(a.SecCalc()-b.SecCalc());
    Time tt(s);
    return tt;
}
Time operator-(Time& a,int t)
{
    int s=fabs(a.SecCalc()-t);
    Time tt(s);
    return tt;
}
int main(){

Time t1(2,34),t2,t3;

t2.SetTime(13,23,34);

cout<<"t1+t2:";

t3=t1+t2;//����Time��������

t3.print_24();

cout<<"\nt1+65:";

t3=t1+65;//Time��������65��

t3.print_24();

cout<<"\n65+t1:";

t3=65+t1;//65�����Time�����

t3.print_24();

cout<<"\nt2-t1:";

t3=t2-t1;//����Time��������

t3.print_24();

cout<<"\nt1-70:";

t3=t1-70;//Time������ȥ70��

t3.print_24();

return 0;

}
