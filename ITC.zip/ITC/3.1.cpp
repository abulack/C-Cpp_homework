#include <iostream>

using namespace std;
int sum(int n)
{
    int s;

    if(n==1)s=1;
    else
        s=n+sum(n-1);
    return s;
}
int main()
{
    int n;
    cin>>n;
    cout <<sum(n) ;
    return 0;
}

