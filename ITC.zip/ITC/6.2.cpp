#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
class Document
{
protected:
    string name;
public:
    Document(string name1)//:name(name1)
    {
        name=name1;
        /*gets(name1);
        strcpy(name,name1);*/
    }
    void PrintNameOf()
    {
        cout<<name<<endl;
    }

};
class Book:public Document
{
private:
    int pageCount;
public:
     Book(string name2,int m):Document(name2)//,pageCount(m)
     {
         pageCount=m;
         //name=name2;Ҫ���û��๹�캯��
        /* gets(name2);
        strcpy(name,name2);*///string�������Ͳ�������strcpy,��ָ�������ʱҪ��strcpy����ֵ��
     }
    void PrintNameOf()
    {
        cout<<"Name of book: ";
        cout<<name;
    }
};
int main() {

Document a("Document1");

Book b("Book1", 100);

a.PrintNameOf();

b.PrintNameOf();

}

