#include <iostream>
#include<cstring>
using namespace std;
class Person;
class Teacher;
class Student;
class Person
{
protected:
      char name[20];
      int age;
      char sex;
public:
    void Register(const char *n,int age,char s)
    {
        strcpy(name,n);
        this->age=age;
        sex=s;
    }

};
class Student:virtual public Person
{
protected:
    char Class[10];
    char id[7];
public:
    Student(const char *n,int age,char s,const char *i,const char* c)
    {
        Register(n,age,s);
        strcpy(id,i);
        strcpy(Class,c);
    }
};
class Teacher:virtual public Person
{
protected:
    char dept[40];
    int salary;
public:
    Teacher(const char *n,int age,char s,const char *d,int sa)
    {
        Register(n,age,s);
        strcpy(dept,d);
        salary=sa;
    }
    };
class Graduate:public Student,public Teacher
{
public:
    Graduate(const char *n,int age,char s,const char *d,int sa,const char *i,const char *c):Teacher(n,age,s,d,sa),Student(n,age,sa,i,c)
    {

    }
    void showMe()
    {
        cout<<"class: "<<Class<<endl;
     cout<<"id: "<<id<<endl;
     cout<<"name: "<<name<<endl;
     cout<<"sex: "<<sex<<endl;
     cout<<"age: "<<age<<endl;
     cout<<"dept: "<<dept<<endl;
     cout<<"salary: "<<salary<<endl;
    }
};
int main(){

  Graduate stu1("Lisi",22,'m',"College of Informatics",2000,"2015013","S101");

  stu1.showMe();

  return 0;

}

