#include <iostream>
#include <cmath>

using namespace std;

int Print(int a, int b )
{
    int x;
    x=sqrt(a*a+b*b);
    if(x<=100)
    {
        cout<<a<<"*"<<a<<" + "<<b<<"*"<<b<<" = "<<x<<"*"<<x<<endl;

    }
    return 0;
}
int Fun(int a, int b)
{
    int i,x;
    a=1,b=100;
    for(i=1;i<b;i++)
    {
        for(a=i+1;a<b;a++)
        {
            x=(int)sqrt(i*i+a*a);
            if((x*x)==(i*i+a*a))
                Print(i,a);
        }
    }
    return 0;
}

int main()
{
    Fun(1,100);
    return 0;
}

