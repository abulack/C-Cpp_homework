#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    char ch;
    scanf("%c",&ch);
    switch (ch)
    {case '0'...'9':cout<<"Digit";break;
    case 'A'...'Z':cout<<"Uppercase Letter";break;
    case 'a'...'z':cout<<"Lowercase Letter";break;
    case ' ':cout<<"Blank Space";break;
    default:cout<<"Others";
    }
    return 0;
}

