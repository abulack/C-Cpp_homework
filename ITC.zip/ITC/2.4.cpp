#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;
int reverse(int n)
{
    int a=0,sum=0,sign;
    if(n>0)
    {
        sign=1;
    }
    else
    {
        sign=-1;
    }
    while(abs(n!=0))
    {
        a=abs(n)%10;
        sum=sum*10+a;
        n=abs(n)/10;
    }
    return sum*sign;



}

int main()
{
  int n,b=0;
  while(cin>>n)
  {
      b=reverse(n);
      cout<<b<<endl;
  }
    return 0;
}

