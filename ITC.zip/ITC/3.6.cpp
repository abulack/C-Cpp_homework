#include <iostream>

using namespace std;
bool huiwen(char s[],int n)
{
    for(int i=0;i<=n/2;i++)
    {
        if(s[i]!=s[n-i-1])
        {
          return false;
        }

        else
            continue;
    }
    return true;
}
int main()
{
    bool flag;
    char s[1000];
    cin>>s;
    int i=0;
    while(s[i]!='\0')
    {
        i++;
    }
    flag = huiwen(s,i);
    if(flag)
        cout<<"yes"<<endl;
    else
        cout<<"no"<<endl;
    return 0;
}

