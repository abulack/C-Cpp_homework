/*#include <iostream>

using namespace std;
#define x 10
void input(int a[]);
void exchange(int *a,int *b);
void sort(int a[]);
int search(int a[],int m);
void exchange(int *a,int *b)
{
    int term;
    term=*a;
    *a=*b;
    *b=term;
}
void sort(int a[])
{
    int i,j;
    for(i=0;i<x-1;i++)
    {
        for(j=0;j<x-1-i;j++)
        {
            if(a[j]>a[j+1])
                exchange(&a[j],&a[j+1]);
            else
                continue;
        }
    }
}
int search(int a[],int m)
{
    int low,high,mid;
    low=0,high=x-1,mid=(low+high)/2;
    while(a[mid]!=m&&low<high)
    {
        if(m>a[mid])
        {
            low=mid+1;
        }
        else
        {
            high=mid-1;
        }
        mid=(low+high)/2;
    }
    if(a[mid]==m)
    {
        return 1;
    }
    else
        return 0;

}
void input(int a[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        cin>>a[i];
    }
}
int main()
{
    int a[x];
    int result;
    int m;
    input(a,x);
    sort(a);
    for(int i=0;i<x;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    cin>>m;
    result = search(a,m);
    if(result==1)cout<<"yes"<<endl;
    else
        cout<<"no"<<endl;




    return 0;
}
*/
#include <iostream>
using namespace std;
void input(int a[][2],int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<2;j++)
            cin>>a[i][j];

    }
}
int searchbei(int a,int b)
{
    int n,max;
    a<b ? max=b : max=a;
    for(n=max;n<=a*b;n++)
    {
        if(n%a==0&&n%b==0)
            return n;
        else
            continue;
    }
}
int searchyin(int a,int b)
{
    int n,min;
    a<b ? min=a : min=b;
    for(n=min;n>=1;n--)
    {
        if(a%n==0&&b%n==0)
            return n;
        else
            continue;
    }
}
int main()
{
    int n,i;
    int a[100][2];
    cin>>n;
    input(a,n);
    for(i=0;i<n;i++)
    {
        cout<<searchyin(a[i][0],a[i][1])<<" "<<searchbei(a[i][0],a[i][1])<<endl;
    }
    return 0;


}

