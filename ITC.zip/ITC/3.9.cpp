#include <iostream>

using namespace std;
int findstr(char * str, char * subStr)
{
	int num = 0;
	while (*str != '\0')
	{
		if (*str != *subStr)
		{
			str++;
			num++;
			continue;
		}


		char * tmpStr = str;
		char * tmpSubStr = subStr;

		while (*tmpSubStr != '\0')
		{
			if (*tmpStr != *tmpSubStr)
			{

				str++;
				num++;
				break;
			}
			tmpStr++;
			tmpSubStr++;
		}

		if (*tmpSubStr == '\0')
		{

			return  1;
		}
	}

	return 0;
}

int main()
{
    char str[1000];
    char substr[100];
    cin>>str;
    cin>>substr;
    cout<<findstr(str,substr);
    return 0;
}

