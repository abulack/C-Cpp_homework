#include <iostream>
#include<cstring>

using namespace std;
class Student
{
private:
    int grade;
    string id;
    string name;
public:
    Student(string name1="***",string id1="000",int grade1=0)
    {
        name=name1;
        id=id1;grade=grade1;
    }

    void setValues(string name1,string id1,int grade1)
    {
        name = name1;
        id=id1;
        grade=grade1;
    }
    void output()
    {
        cout<<"Name:"<<name<<" "<<"id:"<<id<<" grade:"<<grade<<endl;

    }
};
class ArrayOfStudents
{
private:
    Student *p;
    int len;
public:
    ArrayOfStudents(int count);
    ~ArrayOfStudents();
    Student &element(int i);
};
ArrayOfStudents::ArrayOfStudents(int count)
{
    len = count;
    p=new Student[len+1];
}
ArrayOfStudents::~ArrayOfStudents()
{
    delete []p;
    cout<<"Deleting..."<<endl;
}
Student &ArrayOfStudents::element(int i)
{
    return p[i];
}
int  main( ) {

     int count;

     cin >> count;      //������ѧ��������

     ArrayOfStudents stus(count);      //�����������

     stus.element(0).output();

     stus.element(1).output();

     stus.element(0).setValues("ZhangSan", "001", 85);

     stus.element(1).setValues("Lisi", "002", 90);

     stus.element(0).output();

     stus.element(1).output();

     return 0;

}

