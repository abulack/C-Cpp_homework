#include <stdio.h>
#include <stdlib.h>

int isprime(int x)
{int i;
for(i=2;i*i<=x;i++)
if(!(x%i))return 0;
return x>1;
}
int main()
{int i,m,n,x=0;
printf("Input m: ");
scanf("%d",&m);
printf("Input n: ");
scanf("%d",&n);
for(i=m;i<=n;i++)
if(isprime(i))
{printf("%4d",i);
x++;
if(x%6==0)printf("\n");
}
/*if(n==0)printf("no\n");*/
return 0;
}

