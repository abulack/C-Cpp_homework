#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
void Mystrcpy(char s1[],char s2[])
{
    int i;
    for(i=0;s1[i]!='\0';i++ )
    {
        s2[i]=s1[i];
    }
    s2[i]='\0';
}
int main()
{
    char s1[100],s2[100];
    gets(s1);
    Mystrcpy(s1,s2);
    puts(s2);
    puts(s2);
    return 0;
}

