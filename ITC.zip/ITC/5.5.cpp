#include <iostream>
#include <cmath>
using namespace std;
class Point
{

 public:
    Point(int xx,int yy);
    Point(const Point &r);
    ~Point();
    int Getx();
    int Gety();
 private:
    int x,y;
};
Point::Point(int xx,int yy)
{
    x=xx;
    y=yy;
    cout<<"Point's constructor was called"<<endl;
}
Point::Point(const Point &r)
{
    x=r.x;
    y=r.y;
    cout<<"Point's copyConstructor was called"<<endl;
}
Point::~Point()
{
    cout<<"Point's destructor was called"<<endl;
}
int Point::Getx()
{
    return x;
}
int Point::Gety()
{
    return y;
}

class Distance

{

private:
  Point p1,p2;

  double dist;

public:

  Distance(Point a,Point b);

  double GetDis();

  ~Distance();

};
Distance::Distance(Point a,Point b):p1(a),p2(b)
{
    double x = static_cast<double>(p1.Getx()-p2.Getx());
    double y = static_cast<double>(p1.Gety()-p2.Gety());
    dist = sqrt(x*x+y*y);
    cout<<"Distance's constructor was called"<<endl;
}
double Distance::GetDis()
{
    return dist;
}
Distance::~Distance()
{
    cout<<"Distance's destructor was called"<<endl;
}
int main()

{

  Point myp1(1,1),myp2(4,5);

  Distance myd(myp1,myp2);

  cout<<endl;

  cout<<"the distance is:"<<myd.GetDis()<<endl;

  return 0;

}



