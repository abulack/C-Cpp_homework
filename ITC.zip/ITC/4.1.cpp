#include <iostream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
using namespace std;
int MyStrcmp(char sa[],char sb[])
{
    for(int i=0;sa[i]!='\0'||sb[i]!='\0';i++)
    {
        if(sa[i]>sb[i])
            return 1;
        if(sa[i]<sb[i])
            return -1;
        if(sa[i]==sb[i]&&strlen(sa)==strlen(sb))
            return 0;
        if(sa[i]==sb[i])
            continue;
    }
}
int main()
{
    int resp;
    char cha[100],chb[100];
    gets(cha);
    gets(chb);
    resp=MyStrcmp(cha,chb);
    if(resp==1)
        cout<<"����"<<endl;
    else if(resp==-1)
        cout<<"С��"<<endl;
    else
        cout<<"����"<<endl;
    return 0;
}

