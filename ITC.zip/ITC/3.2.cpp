#include <iostream>

using namespace std;

int main()
{
    int i,a[10];
    for(i=0;i<10;i++)
    {
        cin>>a[i];
    }
    int c[9];
    for(int j=0;j<9;j++)
    {
        c[j]=a[j+1]-a[j];
    }

    for(int l=0;l<3;l++)
    {
        for(int k=0;k<3;k++)
        {

            cout<<c[3*l+k]<<" ";

        }
        cout<<endl;
    }

    return 0;
}

